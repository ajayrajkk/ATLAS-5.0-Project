package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.List;

public class ProductPage extends BasePage {

    @FindBy(xpath = "//h2[@class='name']")
    private WebElement productName;

    @FindBy(xpath = "//h3[@class='price-container']")
    private WebElement productPrice;

    @FindBy(xpath = "//a[contains(text(),'Add to cart')]")
    private WebElement addToCartButton;

    @FindBy(xpath = "//div[@id='more-information']//p")
    private WebElement productDescription;

    @FindBy(xpath = "//img[@class='img-responsive']")
    private WebElement productImage;

    @FindBy(xpath = "//a[contains(text(),'Phones')]")
    private WebElement phonesCategory;

    @FindBy(xpath = "//a[contains(text(),'Laptops')]")
    private WebElement laptopsCategory;

    @FindBy(xpath = "//a[contains(text(),'Monitors')]")
    private WebElement monitorsCategory;

    @FindBy(xpath = "//div[@class='card-block']//h4[@class='card-title']//a")
    private List<WebElement> productList;

    public ProductPage(WebDriver driver) {
        super(driver);
    }

    public String getProductName() {
        return getText(productName);
    }

    public String getProductPrice() {
        return getText(productPrice);
    }

    public void addToCart() {
        clickElement(addToCartButton);
    }

    public String getProductDescription() {
        return getText(productDescription);
    }

    public void selectCategory(String category) {
        switch (category.toLowerCase()) {
            case "phones":
                clickElement(phonesCategory);
                break;
            case "laptops":
                clickElement(laptopsCategory);
                break;
            case "monitors":
                clickElement(monitorsCategory);
                break;
        }
    }

    public void selectProduct(String productName) {
        for (WebElement product : productList) {
            if (product.getText().contains(productName)) {
                clickElement(product);
                break;
            }
        }
    }

    public int getProductCount() {
        return productList.size();
    }
}