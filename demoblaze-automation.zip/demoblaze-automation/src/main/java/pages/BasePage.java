package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utils.ConfigManager;



public class BasePage {
    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, ConfigManager.getExplicitWait());
        PageFactory.initElements(driver, this);
    }

    protected void waitForElementToBeClickable(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    protected void waitForElementToBeVisible(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    protected void clickElement(WebElement element) {
        // Close any open modals first
        try {
            driver.findElement(org.openqa.selenium.By.xpath("//button[@class='close' or contains(@class,'btn-secondary') or contains(text(),'Close')]")).click();
            Thread.sleep(500);
        } catch (Exception e) {
            // No modal to close
        }
        
        waitForElementToBeClickable(element);
        element.click();
        
        // Handle any alerts that might appear after clicking
        try {
            Thread.sleep(1000);
            if (driver.switchTo().alert() != null) {
                driver.switchTo().alert().accept();
            }
        } catch (Exception e) {
            // No alert present, continue
        }
    }

    protected void sendKeys(WebElement element, String text) {
        waitForElementToBeVisible(element);
        element.clear();
        element.sendKeys(text);
    }

    protected String getText(WebElement element) {
        waitForElementToBeVisible(element);
        return element.getText();
    }

    protected boolean isElementDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public WebDriver getDriver() {
        return driver;
    }
}