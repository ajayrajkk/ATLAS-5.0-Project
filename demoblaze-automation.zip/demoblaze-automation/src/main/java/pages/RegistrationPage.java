package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage extends BasePage {

    @FindBy(id = "sign-username")
    private WebElement usernameField;

    @FindBy(id = "sign-password")
    private WebElement passwordField;

    @FindBy(xpath = "//button[contains(text(),'Sign up')]")
    private WebElement signUpButton;

    @FindBy(xpath = "//div[@id='signInModal']//button[contains(text(),'Close')]")
    private WebElement closeButton;

    @FindBy(id = "signInModal")
    private WebElement signUpModal;

    @FindBy(xpath = "//div[@id='signInModal']//h4[@class='modal-title']")
    private WebElement signUpModalTitle;

    public RegistrationPage(WebDriver driver) {
        super(driver);
    }

    public void enterUsername(String username) {
        sendKeys(usernameField, username);
    }

    public void enterPassword(String password) {
        sendKeys(passwordField, password);
    }

    public void clickSignUpButton() {
        clickElement(signUpButton);
    }

    public void clickCloseButton() {
        clickElement(closeButton);
    }

    public void register(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickSignUpButton();
    }

    public boolean isSignUpModalDisplayed() {
        try {
            waitForElementToBeVisible(signUpModal);
            return signUpModal.isDisplayed() && signUpModal.getAttribute("class").contains("show");
        } catch (Exception e) {
            return false;
        }
    }
}