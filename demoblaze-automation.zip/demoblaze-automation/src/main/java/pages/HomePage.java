package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

    @FindBy(id = "login2")
    private WebElement loginLink;

    @FindBy(id = "signin2")
    private WebElement signUpLink;

    @FindBy(id = "cartur")
    private WebElement cartLink;

    @FindBy(xpath = "//a[contains(text(),'Home')]")
    private WebElement homeLink;

    @FindBy(xpath = "//a[contains(text(),'Contact')]")
    private WebElement contactLink;

    @FindBy(xpath = "//a[contains(text(),'About us')]")
    private WebElement aboutUsLink;

    @FindBy(id = "nameofuser")
    private WebElement welcomeMessage;

    @FindBy(id = "logout2")
    private WebElement logoutLink;

    @FindBy(xpath = "//div[@class='card-block']//h4[@class='card-title']//a")
    private WebElement firstProduct;

    @FindBy(xpath = "//div[@class='card-block']//h4[@class='card-title']//a")
    private java.util.List<WebElement> allProducts;

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void clickLogin() {
        clickElement(loginLink);
    }

    public void clickSignUp() {
        clickElement(signUpLink);
    }

    public void clickCart() {
        clickElement(cartLink);
    }

    public void clickFirstProduct() {
        clickElement(firstProduct);
    }

    public boolean isUserLoggedIn() {
        return isElementDisplayed(welcomeMessage);
    }

    public void logout() {
        if (isUserLoggedIn()) {
            clickElement(logoutLink);
        }
    }

    public String getWelcomeMessage() {
        return getText(welcomeMessage);
    }

    public int getProductCount() {
        try {
            Thread.sleep(2000); // Wait for products to load
            return allProducts.size();
        } catch (Exception e) {
            return 0;
        }
    }
}