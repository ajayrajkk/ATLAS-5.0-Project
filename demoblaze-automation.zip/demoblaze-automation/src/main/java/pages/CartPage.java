package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.List;

public class CartPage extends BasePage {

    @FindBy(xpath = "//button[contains(text(),'Place Order')]")
    private WebElement placeOrderButton;

    @FindBy(xpath = "//tr[@class='success']//td[2]")
    private List<WebElement> productNames;

    @FindBy(xpath = "//tr[@class='success']//td[3]")
    private List<WebElement> productPrices;

    @FindBy(xpath = "//tr[@class='success']//td[4]//a")
    private List<WebElement> deleteButtons;

    @FindBy(id = "totalp")
    private WebElement totalPrice;

    @FindBy(id = "name")
    private WebElement nameField;

    @FindBy(id = "country")
    private WebElement countryField;

    @FindBy(id = "city")
    private WebElement cityField;

    @FindBy(id = "card")
    private WebElement creditCardField;

    @FindBy(id = "month")
    private WebElement monthField;

    @FindBy(id = "year")
    private WebElement yearField;

    @FindBy(xpath = "//button[contains(text(),'Purchase')]")
    private WebElement purchaseButton;

    @FindBy(xpath = "//button[contains(text(),'Close')]")
    private WebElement closeOrderButton;

    @FindBy(xpath = "//h2[contains(text(),'Thank you for your purchase!')]")
    private WebElement orderConfirmation;

    public CartPage(WebDriver driver) {
        super(driver);
    }

    public void clickPlaceOrder() {
        clickElement(placeOrderButton);
    }

    public void removeProduct(int index) {
        if (index < deleteButtons.size()) {
            int initialCount = getProductCount();
            clickElement(deleteButtons.get(index));
            // Wait for the product to be removed from DOM
            try {
                Thread.sleep(2000);
                // Wait until product count decreases
                int attempts = 0;
                while (getProductCount() >= initialCount && attempts < 10) {
                    Thread.sleep(500);
                    attempts++;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public String getTotalPrice() {
        return getText(totalPrice);
    }

    public int getProductCount() {
        return productNames.size();
    }

    public void fillOrderForm(String name, String country, String city, String card, String month, String year) {
        sendKeys(nameField, name);
        sendKeys(countryField, country);
        sendKeys(cityField, city);
        sendKeys(creditCardField, card);
        sendKeys(monthField, month);
        sendKeys(yearField, year);
    }

    public void completePurchase() {
        clickElement(purchaseButton);
    }

    public boolean isOrderConfirmed() {
        return isElementDisplayed(orderConfirmation);
    }

    public void closeOrder() {
        clickElement(closeOrderButton);
    }
}