package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage {

    @FindBy(id = "loginusername")
    private WebElement usernameField;

    @FindBy(id = "loginpassword")
    private WebElement passwordField;

    @FindBy(xpath = "//button[contains(text(),'Log in')]")
    private WebElement loginButton;

    @FindBy(xpath = "//div[@id='logInModal']//button[contains(text(),'Close') or @class='close']")
    private WebElement closeButton;
    
    @FindBy(xpath = "//button[@class='close']")
    private WebElement modalCloseX;

    @FindBy(id = "logInModal")
    private WebElement loginModal;

    @FindBy(xpath = "//div[@id='logInModal']//h4[@class='modal-title']")
    private WebElement loginModalTitle;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void enterUsername(String username) {
        sendKeys(usernameField, username);
    }

    public void enterPassword(String password) {
        sendKeys(passwordField, password);
    }

    public void clickLoginButton() {
        clickElement(loginButton);
    }

    public void clickCloseButton() {
        try {
            clickElement(closeButton);
        } catch (Exception e) {
            try {
                clickElement(modalCloseX);
            } catch (Exception ex) {
                // Modal might already be closed
                System.out.println("Modal close button not found - modal might be closed");
            }
        }
    }

    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }

    public boolean isLoginModalDisplayed() {
        try {
            waitForElementToBeVisible(loginModal);
            return loginModal.isDisplayed() && loginModal.getAttribute("class").contains("show");
        } catch (Exception e) {
            return false;
        }
    }
}