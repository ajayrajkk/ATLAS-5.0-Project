package data;

import org.testng.annotations.DataProvider;
import utils.ExcelReader;

public class TestDataProvider {
    
    private static final String EXCEL_FILE_PATH = "src/main/resources/testdata.xlsx";

    @DataProvider(name = "loginData")
    public static Object[][] getLoginData() {
        ExcelReader excelReader = new ExcelReader(EXCEL_FILE_PATH);
        Object[][] data = excelReader.getTestData("Login");
        excelReader.close();
        return data;
    }

    @DataProvider(name = "registrationData")
    public static Object[][] getRegistrationData() {
        ExcelReader excelReader = new ExcelReader(EXCEL_FILE_PATH);
        Object[][] data = excelReader.getTestData("Registration");
        excelReader.close();
        return data;
    }

    @DataProvider(name = "productData")
    public static Object[][] getProductData() {
        ExcelReader excelReader = new ExcelReader(EXCEL_FILE_PATH);
        Object[][] data = excelReader.getTestData("Products");
        excelReader.close();
        return data;
    }

    @DataProvider(name = "checkoutData")
    public static Object[][] getCheckoutData() {
        ExcelReader excelReader = new ExcelReader(EXCEL_FILE_PATH);
        Object[][] data = excelReader.getTestData("Checkout");
        excelReader.close();
        return data;
    }
}