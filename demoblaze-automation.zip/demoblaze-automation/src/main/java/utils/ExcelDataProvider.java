package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelDataProvider {
    
    public static void createTestDataExcel() {
        String filePath = "src/main/resources/testdata.xlsx";
        
        try (Workbook workbook = new XSSFWorkbook()) {
            
            // Create Login sheet
            Sheet loginSheet = workbook.createSheet("Login");
            createLoginData(loginSheet);
            
            // Create Registration sheet
            Sheet registrationSheet = workbook.createSheet("Registration");
            createRegistrationData(registrationSheet);
            
            // Create Products sheet
            Sheet productsSheet = workbook.createSheet("Products");
            createProductsData(productsSheet);
            
            // Create Checkout sheet
            Sheet checkoutSheet = workbook.createSheet("Checkout");
            createCheckoutData(checkoutSheet);
            
            // Write to file
            try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                workbook.write(fileOut);
            }
            
        } catch (IOException e) {
            throw new RuntimeException("Failed to create Excel file: " + e.getMessage());
        }
    }
    
    private static void createLoginData(Sheet sheet) {
        String[][] data = {
            {"Username", "Password", "Expected"},
            {"testuser1", "testpass1", "success"},
            {"testuser2", "testpass2", "success"},
            {"invaliduser", "validpass", "failure"},
            {"validuser", "invalidpass", "failure"}
        };
        createSheetData(sheet, data);
    }
    
    private static void createRegistrationData(Sheet sheet) {
        String[][] data = {
            {"Username", "Password", "Expected"},
            {"newuser1", "password123", "success"},
            {"newuser2", "strongpass456", "success"},
            {"existinguser", "password123", "failure"}
        };
        createSheetData(sheet, data);
    }
    
    private static void createProductsData(Sheet sheet) {
        String[][] data = {
            {"ProductName", "Category", "Price"},
            {"Samsung galaxy s6", "Phones", "360"},
            {"Nokia lumia 1520", "Phones", "820"},
            {"Nexus 6", "Phones", "650"},
            {"Sony vaio i5", "Laptops", "790"},
            {"MacBook air", "Laptops", "700"}
        };
        createSheetData(sheet, data);
    }
    
    private static void createCheckoutData(Sheet sheet) {
        String[][] data = {
            {"Name", "Country", "City", "Card", "Month", "Year"},
            {"John Doe", "USA", "New York", "1234567890123456", "12", "2025"},
            {"Jane Smith", "Canada", "Toronto", "9876543210987654", "06", "2026"},
            {"Bob Johnson", "UK", "London", "1111222233334444", "03", "2027"}
        };
        createSheetData(sheet, data);
    }
    
    private static void createSheetData(Sheet sheet, String[][] data) {
        for (int i = 0; i < data.length; i++) {
            Row row = sheet.createRow(i);
            for (int j = 0; j < data[i].length; j++) {
                Cell cell = row.createCell(j);
                cell.setCellValue(data[i][j]);
            }
        }
    }
    
    public static void main(String[] args) {
        createTestDataExcel();
        System.out.println("Excel file created successfully!");
    }
}