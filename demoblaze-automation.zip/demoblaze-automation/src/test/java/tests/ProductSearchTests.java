package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ProductSearchTests extends BaseTest {

    @Test(priority = 1)
    public void testSearchByProductName() {
        productPage.selectProduct("Samsung galaxy s6");
        Assert.assertTrue(productPage.getProductName().contains("Samsung"), "Product should be found");
    }

    @Test(priority = 2)
    public void testSearchByCategory() {
        productPage.selectCategory("phones");
        Assert.assertTrue(productPage.getProductCount() > 0, "Products should be displayed in category");
    }

    @Test(priority = 3)
    public void testLaptopsCategory() {
        productPage.selectCategory("laptops");
        Assert.assertTrue(productPage.getProductCount() > 0, "Laptops should be displayed");
    }

    @Test(priority = 4)
    public void testMonitorsCategory() {
        productPage.selectCategory("monitors");
        Assert.assertTrue(productPage.getProductCount() > 0, "Monitors should be displayed");
    }

    @Test(priority = 5)
    public void testProductDisplay() {
        Assert.assertTrue(productPage.getProductCount() > 0, "Products should be displayed on home page");
    }
}