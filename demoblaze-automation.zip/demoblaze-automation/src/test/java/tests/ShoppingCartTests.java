package tests;

import managers.DriverManager;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ShoppingCartTests extends BaseTest {

    @Test(priority = 1, groups = {"smoke", "ecommerce", "regression"})
    public void testAddProductToCart() {
        homePage.clickFirstProduct();
        productPage.addToCart();
        // Handle alert
        try {
            Thread.sleep(2000);
            DriverManager.getDriver().switchTo().alert().accept();
        } catch (Exception e) {
            // Alert handling
        }
        
        homePage.clickCart();
        Assert.assertTrue(cartPage.getProductCount() > 0, "Product should be added to cart");
    }

    @Test(priority = 2, groups = {"ecommerce", "regression"})
    public void testRemoveProductFromCart() {
        // First add a product
        testAddProductToCart();
        
        int initialCount = cartPage.getProductCount();
        if (initialCount > 0) {
            cartPage.removeProduct(0);
            Assert.assertTrue(cartPage.getProductCount() < initialCount, "Product should be removed from cart");
        }
    }

    @Test(priority = 3, groups = {"ecommerce", "regression"})
    public void testCartPersistence() {
        testAddProductToCart();
        navigateToHome();
        homePage.clickCart();
        Assert.assertTrue(cartPage.getProductCount() > 0, "Cart should persist across sessions");
    }

    @Test(priority = 4, groups = {"ecommerce", "regression"})
    public void testPriceCalculation() {
        testAddProductToCart();
        String totalPrice = cartPage.getTotalPrice();
        Assert.assertNotNull(totalPrice, "Total price should be calculated");
    }

    @Test(priority = 5, groups = {"smoke", "ecommerce", "regression"})
    public void testEmptyCart() {
        homePage.clickCart();
        // Verify empty cart state
        Assert.assertTrue(cartPage.getProductCount() >= 0, "Cart should handle empty state");
    }
}