package tests;

import managers.DriverManager;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckoutTests extends BaseTest {

    @Test(priority = 1)
    public void testCheckoutAsGuestUser() {
        // Add product to cart first
        homePage.clickFirstProduct();
        productPage.addToCart();
        
        try {
            Thread.sleep(2000);
            DriverManager.getDriver().switchTo().alert().accept();
        } catch (Exception e) {
            // Alert handling
        }
        
        homePage.clickCart();
        cartPage.clickPlaceOrder();
        cartPage.fillOrderForm("John Doe", "USA", "New York", "1234567890123456", "12", "2025");
        cartPage.completePurchase();
        
        Assert.assertTrue(cartPage.isOrderConfirmed(), "Order should be confirmed");
    }

    @Test(priority = 2)
    public void testCheckoutAsRegisteredUser() {
        // Login first
        homePage.clickLogin();
        loginPage.login("testuser", "testpass");
        
        // Handle login alert and close modal
        if (alertHandler.isAlertPresent()) {
            alertHandler.acceptAlert();
        }
        
        // Ensure modal is closed before proceeding
        try {
            loginPage.clickCloseButton();
            Thread.sleep(1000);
        } catch (Exception e) {
            // Modal might already be closed
        }
        
        // Add product and checkout
        homePage.clickFirstProduct();
        productPage.addToCart();
        
        try {
            Thread.sleep(2000);
            DriverManager.getDriver().switchTo().alert().accept();
        } catch (Exception e) {
            // Alert handling
        }
        
        homePage.clickCart();
        cartPage.clickPlaceOrder();
        cartPage.fillOrderForm("Jane Doe", "Canada", "Toronto", "9876543210987654", "06", "2026");
        cartPage.completePurchase();
        
        Assert.assertTrue(cartPage.isOrderConfirmed(), "Order should be confirmed for registered user");
    }

    @Test(priority = 3)
    public void testShippingAddressValidation() {
        homePage.clickFirstProduct();
        productPage.addToCart();
        
        try {
            Thread.sleep(2000);
            DriverManager.getDriver().switchTo().alert().accept();
        } catch (Exception e) {
            // Alert handling
        }
        
        homePage.clickCart();
        cartPage.clickPlaceOrder();
        cartPage.fillOrderForm("", "", "", "1234567890123456", "12", "2025");
        // Should validate required fields
    }

    @Test(priority = 4)
    public void testPaymentMethodSelection() {
        homePage.clickFirstProduct();
        productPage.addToCart();
        
        try {
            Thread.sleep(2000);
            DriverManager.getDriver().switchTo().alert().accept();
        } catch (Exception e) {
            // Alert handling
        }
        
        homePage.clickCart();
        cartPage.clickPlaceOrder();
        cartPage.fillOrderForm("Test User", "India", "Mumbai", "", "12", "2025");
        // Should validate payment method
    }

    @Test(priority = 5)
    public void testOrderConfirmation() {
        homePage.clickFirstProduct();
        productPage.addToCart();
        
        try {
            Thread.sleep(2000);
            DriverManager.getDriver().switchTo().alert().accept();
        } catch (Exception e) {
            // Alert handling
        }
        
        homePage.clickCart();
        cartPage.clickPlaceOrder();
        cartPage.fillOrderForm("Confirmation Test", "UK", "London", "1111222233334444", "03", "2027");
        cartPage.completePurchase();
        
        Assert.assertTrue(cartPage.isOrderConfirmed(), "Order confirmation should be displayed");
        // Don't try to close order confirmation - let tearDown handle cleanup
        System.out.println("Order confirmation test completed successfully");
    }
}