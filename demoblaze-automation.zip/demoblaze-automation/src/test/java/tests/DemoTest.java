package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DemoTest extends BaseTest {

    @Test(priority = 1)
    public void testWebsiteTitle() {
        String title = homePage.getDriver().getTitle();
        System.out.println("Website title: " + title);
        Assert.assertNotNull(title, "Website title should not be null");
    }

    @Test(priority = 2)
    public void testLoginModalDisplay() {
        homePage.clickLogin();
        Assert.assertTrue(loginPage.isLoginModalDisplayed(), "Login modal should be displayed");
        loginPage.clickCloseButton();
    }

    @Test(priority = 3)
    public void testSignUpModalDisplay() {
        homePage.clickSignUp();
        Assert.assertTrue(registrationPage.isSignUpModalDisplayed(), "Sign up modal should be displayed");
        registrationPage.clickCloseButton();
    }
}