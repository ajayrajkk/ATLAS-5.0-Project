package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class BasicFunctionalityTests extends BaseTest {

    @Test(priority = 1, groups = {"smoke", "regression"})
    public void testWebsiteLoads() {
        String title = homePage.getDriver().getTitle();
        System.out.println("Website title: " + title);
        Assert.assertNotNull(title, "Website should load successfully");
    }

    @Test(priority = 2, groups = {"smoke", "user-management", "regression"})
    public void testLoginModalOpens() {
        homePage.clickLogin();
        try {
            Thread.sleep(2000); // Wait for modal to appear
            Assert.assertTrue(loginPage.isLoginModalDisplayed(), "Login modal should open");
            loginPage.clickCloseButton();
        } catch (Exception e) {
            System.out.println("Login modal test completed with exception: " + e.getMessage());
        }
    }

    @Test(priority = 3, groups = {"smoke", "user-management", "regression"})
    public void testSignUpModalOpens() {
        homePage.clickSignUp();
        try {
            Thread.sleep(2000); // Wait for modal to appear
            Assert.assertTrue(registrationPage.isSignUpModalDisplayed(), "Sign up modal should open");
            registrationPage.clickCloseButton();
        } catch (Exception e) {
            System.out.println("Sign up modal test completed with exception: " + e.getMessage());
        }
    }

    @Test(priority = 4, groups = {"smoke", "ecommerce", "regression"})
    public void testProductsDisplayed() {
        int productCount = productPage.getProductCount();
        System.out.println("Number of products displayed: " + productCount);
        Assert.assertTrue(productCount > 0, "Products should be displayed on home page");
    }

    @Test(priority = 5, groups = {"smoke", "ecommerce", "regression"})
    public void testCartPageAccess() {
        homePage.clickCart();
        String currentUrl = homePage.getDriver().getCurrentUrl();
        System.out.println("Current URL: " + currentUrl);
        Assert.assertTrue(currentUrl.contains("cart"), "Should navigate to cart page");
    }
}