package tests;

import managers.DriverManager;
import org.testng.annotations.*;
import pages.*;
import utils.AlertHandler;
import utils.ConfigManager;

public class BaseTest {
    protected HomePage homePage;
    protected LoginPage loginPage;
    protected RegistrationPage registrationPage;
    protected ProductPage productPage;
    protected CartPage cartPage;
    protected AlertHandler alertHandler;

    @BeforeMethod
    @Parameters("browser")
    public void setUp(@Optional String browser) {
        if (browser == null) {
            browser = ConfigManager.getBrowser();
        }
        
        DriverManager.setDriver(browser);
        DriverManager.getDriver().get(ConfigManager.getUrl());
        
        initializePages();
    }

    @AfterMethod
    public void tearDown() {
        DriverManager.quitDriver();
    }

    private void initializePages() {
        homePage = new HomePage(DriverManager.getDriver());
        loginPage = new LoginPage(DriverManager.getDriver());
        registrationPage = new RegistrationPage(DriverManager.getDriver());
        productPage = new ProductPage(DriverManager.getDriver());
        cartPage = new CartPage(DriverManager.getDriver());
        alertHandler = new AlertHandler(DriverManager.getDriver());
    }

    protected void navigateToHome() {
        DriverManager.getDriver().get(ConfigManager.getUrl());
    }
}