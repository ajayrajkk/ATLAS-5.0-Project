package suites;

import org.testng.annotations.Test;
import tests.*;

/**
 * Smoke Test Suite - Critical functionality tests
 * Run these tests first to ensure basic functionality works
 */
public class SmokeTestSuite {
    
    @Test(groups = {"smoke"})
    public void runSmokeTests() {
        // This class serves as a marker for smoke tests
        // Actual tests are in individual test classes with @Test(groups = {"smoke"})
    }
}