package suites;

import org.testng.annotations.Test;

/**
 * Regression Test Suite - Complete functionality tests
 * Run all tests to ensure no existing functionality is broken
 */
public class RegressionTestSuite {
    
    @Test(groups = {"regression"})
    public void runRegressionTests() {
        // This class serves as a marker for regression tests
        // Actual tests are in individual test classes with @Test(groups = {"regression"})
    }
}