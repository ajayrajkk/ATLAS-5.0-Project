package suites;

import org.testng.annotations.Test;

/**
 * User Management Test Suite - Login and Registration tests
 * Tests related to user authentication and account management
 */
public class UserManagementSuite {
    
    @Test(groups = {"user-management"})
    public void runUserManagementTests() {
        // This class serves as a marker for user management tests
        // Actual tests are in LoginTests and RegistrationTests classes
    }
}