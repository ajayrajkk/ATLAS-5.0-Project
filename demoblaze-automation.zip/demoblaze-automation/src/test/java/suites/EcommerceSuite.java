package suites;

import org.testng.annotations.Test;

/**
 * E-commerce Test Suite - Shopping and checkout tests
 * Tests related to product browsing, cart operations, and checkout process
 */
public class EcommerceSuite {
    
    @Test(groups = {"ecommerce"})
    public void runEcommerceTests() {
        // This class serves as a marker for e-commerce tests
        // Actual tests are in ProductSearchTests, ShoppingCartTests, and CheckoutTests classes
    }
}