# Demoblaze Selenium Automation Framework

A comprehensive Selenium automation framework implementing Page Object Model design pattern with TestNG for testing the Demoblaze e-commerce website.

## Features

- **Page Object Model**: Improved maintainability and reduced code duplication
- **TestNG Integration**: Parallel execution, parameterization, and detailed reports
- **Data-Driven Testing**: Excel-based test data management for scalability
- **Multi-Browser Support**: Chrome and Firefox support with easy configuration
- **Screenshot Capture**: Automatic screenshot capture on test failures
- **Configuration Management**: Centralized configuration through properties files

## Framework Structure

```
demoblaze-automation/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   ├── data/
│   │   │   │   └── TestDataProvider.java
│   │   │   ├── managers/
│   │   │   │   └── DriverManager.java
│   │   │   ├── pages/
│   │   │   │   ├── BasePage.java
│   │   │   │   ├── CartPage.java
│   │   │   │   ├── HomePage.java
│   │   │   │   ├── LoginPage.java
│   │   │   │   ├── ProductPage.java
│   │   │   │   └── RegistrationPage.java
│   │   │   └── utils/
│   │   │       ├── AlertHandler.java
│   │   │       ├── ConfigManager.java
│   │   │       └── ExcelReader.java
│   │   └── resources/
│   │       ├── config.properties
│   │       ├── testdata-structure.txt
│   │       ├── testng-basic.xml
│   │       ├── testng-chrome-only.xml
│   │       ├── testng-demo.xml
│   │       └── testng.xml
│   └── test/
│       └── java/
│           ├── listeners/
│           │   └── TestListener.java
│           ├── suites/
│           └── tests/
│               ├── BaseTest.java
│               ├── BasicFunctionalityTests.java
│               ├── CheckoutTests.java
│               ├── DemoTest.java
│               ├── LoginTests.java
│               ├── ProductSearchTests.java
│               ├── RegistrationTests.java
│               └── ShoppingCartTests.java
├── target/                     # Compiled classes and test reports
├── output/
│   ├── logs/
│   ├── screenshots/            # Test failure screenshots
│   └── test-output/
├── pom.xml
├── README.md
├── run-tests.bat
├── FINAL-ANALYSIS.md
├── FRAMEWORK-STATUS.md
├── PROJECT-SUMMARY.md
├── TEST-FAILURE-ANALYSIS.md
└── TEST-RESULTS-ANALYSIS.md
```

## Test Coverage (25+ Tests)

### Login Tests (5 tests)
- Successful login with valid credentials
- Login with invalid username
- Login with invalid password
- Login with empty credentials
- Login modal display validation

### Registration Tests (5 tests)
- Successful registration
- Registration with existing email
- Password strength validation
- Mandatory field validation
- Sign-up modal display

### Product Search Tests (5 tests)
- Search by product name
- Search by category (Phones)
- Search by category (Laptops)
- Search by category (Monitors)
- Product display validation

### Shopping Cart Tests (5 tests)
- Add product to cart
- Remove product from cart
- Cart persistence across sessions
- Price calculation verification
- Empty cart handling

### Checkout Tests (5 tests)
- Checkout as guest user
- Checkout as registered user
- Shipping address validation
- Payment method selection
- Order confirmation

## Setup Instructions

1. **Prerequisites**
   - Java 11 or higher
   - Maven 3.6 or higher
   - Chrome and/or Firefox browsers

2. **Installation**
   ```bash
   cd demoblaze-automation
   mvn clean install
   ```

3. **Configuration**
   - Update `src/main/resources/config.properties` as needed
   - Create Excel test data file based on `testdata-structure.txt`

4. **Running Tests**
   ```bash
   # Run all tests
   mvn test

   # Run specific test suite
   mvn test -Dsurefire.suiteXmlFiles=src/main/resources/testng.xml

   # Run with specific browser
   mvn test -Dbrowser=chrome
   mvn test -Dbrowser=firefox
   ```

## Configuration

### config.properties
```properties
browser=chrome
url=https://www.demoblaze.com
implicit.wait=10
explicit.wait=20
testdata.file=testdata.xlsx
screenshot.on.failure=true
```

### TestNG XML
- Parallel execution support
- Cross-browser testing
- Test listener integration
- Parameter passing

## Reporting

- **TestNG Reports**: Generated in `output/test-output/`
- **Screenshots**: Captured on failure in `output/screenshots/`
- **Console Logs**: Test execution details

## Best Practices Implemented

- Page Object Model design pattern
- Explicit waits for better synchronization
- ThreadLocal WebDriver for parallel execution
- Configuration externalization
- Data-driven testing approach
- Proper exception handling
- Screenshot capture on failures
- Modular and maintainable code structure

## Browser Support

- **Chrome**: Default browser with optimized options
- **Firefox**: Alternative browser support
- **WebDriverManager**: Automatic driver management

## Future Enhancements

- ExtentReports integration
- Database connectivity for test data
- API testing integration
- Docker containerization
- CI/CD pipeline integration
- Allure reporting
- Mobile testing support