package com.scms.util;

import java.util.Scanner;

/**
 * Utility class for console operations
 */
public class ConsoleHelper {
    private static final Scanner scanner = new Scanner(System.in);
    
    public static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    
    public static int readInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Please try again.");
            }
        }
    }
    
    public static double readDouble(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Please try again.");
            }
        }
    }
    
    public static void printLine() {
        System.out.println("----------------------------------------");
    }
    
    public static void printHeader(String title) {
        printLine();
        System.out.println("  " + title);
        printLine();
    }
    
    public static void printSuccess(String message) {
        System.out.println("✓ " + message);
    }
    
    public static void printError(String message) {
        System.out.println("✗ Error: " + message);
    }
    
    public static void printWarning(String message) {
        System.out.println("⚠ Warning: " + message);
    }
    
    public static void pause() {
        System.out.print("Press Enter to continue...");
        scanner.nextLine();
    }
}