package com.scms.util;

/**
 * Utility class for input validation
 */
public class InputValidator {
    
    public static boolean isValidId(String id) {
        return id != null && !id.trim().isEmpty() && id.matches("^[A-Za-z0-9_-]+$");
    }
    
    public static boolean isValidName(String name) {
        return name != null && !name.trim().isEmpty() && name.length() >= 2;
    }
    
    public static boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }
    
    public static boolean isValidPrice(double price) {
        return price >= 0;
    }
    
    public static boolean isValidQuantity(int quantity) {
        return quantity >= 0;
    }
    
    public static boolean isValidPhone(String phone) {
        return phone != null && phone.matches("^[+]?[0-9\\s\\-()]{7,15}$");
    }
    
    public static String sanitizeInput(String input) {
        return input != null ? input.trim() : null;
    }
}