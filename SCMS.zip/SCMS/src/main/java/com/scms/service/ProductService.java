package com.scms.service;

import com.scms.model.Product;
import com.scms.model.ProductCategory;
import com.scms.repository.ProductRepository;
import com.scms.exception.ProductNotFoundException;
import com.scms.exception.InvalidProductDataException;
import java.math.BigDecimal;
import java.util.List;

/**
 * Service class for Product business logic operations
 */
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product createProduct(String productId, String name, String description, 
                               ProductCategory category, BigDecimal price) {
        validateProductData(productId, name, price);
        
        if (productRepository.existsById(productId)) {
            throw new InvalidProductDataException("Product with ID " + productId + " already exists");
        }

        Product product = new Product(productId, name, description, category, price);
        return productRepository.save(product);
    }

    public Product getProductById(String productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + productId));
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public List<Product> getProductsByCategory(ProductCategory category) {
        return productRepository.findByCategory(category);
    }

    public Product updateProduct(String productId, String name, String description, 
                               ProductCategory category, BigDecimal price) {
        Product existingProduct = getProductById(productId);
        
        if (name != null) existingProduct.setName(name);
        if (description != null) existingProduct.setDescription(description);
        if (category != null) existingProduct.setCategory(category);
        if (price != null && price.compareTo(BigDecimal.ZERO) >= 0) existingProduct.setUnitPrice(price);

        return productRepository.save(existingProduct);
    }

    public void deleteProduct(String productId) {
        if (!productRepository.existsById(productId)) {
            throw new ProductNotFoundException("Product not found with ID: " + productId);
        }
        productRepository.deleteById(productId);
    }

    public void updatePrice(String productId, BigDecimal newPrice) {
        Product product = getProductById(productId);
        
        if (newPrice.compareTo(BigDecimal.ZERO) < 0) {
            throw new InvalidProductDataException("Price cannot be negative");
        }
        
        product.setUnitPrice(newPrice);
        productRepository.save(product);
    }

    private void validateProductData(String productId, String name, BigDecimal price) {
        if (productId == null || productId.trim().isEmpty()) {
            throw new InvalidProductDataException("Product ID cannot be null or empty");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new InvalidProductDataException("Product name cannot be null or empty");
        }
        if (price != null && price.compareTo(BigDecimal.ZERO) < 0) {
            throw new InvalidProductDataException("Product price cannot be negative");
        }
    }
}