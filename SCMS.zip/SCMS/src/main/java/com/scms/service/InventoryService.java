package com.scms.service;

import com.scms.model.InventoryItem;
import com.scms.repository.InventoryRepository;
import com.scms.exception.InsufficientStockException;
import com.scms.exception.InvalidQuantityException;
import java.time.LocalDateTime;
import java.util.*;

public class InventoryService {
    private final InventoryRepository inventoryRepository;

    public InventoryService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    public void addStock(String productId, String warehouseId, int quantity) throws InvalidQuantityException {
        if (quantity < 0) {
            throw new InvalidQuantityException(quantity);
        }
        Optional<InventoryItem> existing = inventoryRepository.findByProductAndWarehouse(productId, warehouseId);
        if (existing.isPresent()) {
            InventoryItem item = existing.get();
            item.setQuantity(item.getQuantity() + quantity);
            item.setLastRestockedDate(LocalDateTime.now());
            inventoryRepository.save(item);
        } else {
            String itemId = productId + "_" + warehouseId + "_" + System.currentTimeMillis();
            InventoryItem newItem = new InventoryItem(itemId, productId, warehouseId, quantity, LocalDateTime.now());
            inventoryRepository.save(newItem);
        }
    }

    public void removeStock(String productId, String warehouseId, int quantity) throws InsufficientStockException, InvalidQuantityException {
        if (quantity <= 0) {
            throw new InvalidQuantityException(quantity);
        }
        InventoryItem item = inventoryRepository.findByProductAndWarehouse(productId, warehouseId)
                .orElseThrow(() -> new InsufficientStockException(productId, quantity, 0));
        
        if (item.getQuantity() < quantity) {
            throw new InsufficientStockException(productId, quantity, item.getQuantity());
        }
        
        item.setQuantity(item.getQuantity() - quantity);
        inventoryRepository.save(item);
    }

    public int getStockLevel(String productId, String warehouseId) {
        return inventoryRepository.findByProductAndWarehouse(productId, warehouseId)
                .map(InventoryItem::getQuantity)
                .orElse(0);
    }

    public void transferStock(String productId, String fromWarehouseId, String toWarehouseId, int quantity) throws InsufficientStockException, InvalidQuantityException {
        if (quantity < 0) {
            throw new InvalidQuantityException(quantity);
        }
        removeStock(productId, fromWarehouseId, quantity);
        addStock(productId, toWarehouseId, quantity);
    }
}