package com.scms.service;

import com.scms.model.Supplier;
import com.scms.repository.SupplierRepository;
import java.util.List;

public class SupplierService {
    private final SupplierRepository supplierRepository;

    public SupplierService(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    public Supplier createSupplier(String supplierId, String name, String contactInfo, double rating) {
        Supplier supplier = new Supplier(supplierId, name, contactInfo, rating);
        return supplierRepository.save(supplier);
    }

    public List<Supplier> getAllSuppliers() {
        return supplierRepository.findAll();
    }

    public void updateSupplierRating(String supplierId, double rating) {
        supplierRepository.findById(supplierId).ifPresent(supplier -> {
            supplier.setRating(rating);
            supplierRepository.save(supplier);
        });
    }

    public List<Supplier> getTopRatedSuppliers(double minRating) {
        return supplierRepository.findByRatingAbove(minRating);
    }
}