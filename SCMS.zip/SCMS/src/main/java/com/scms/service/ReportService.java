package com.scms.service;

import com.scms.model.*;
import com.scms.repository.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class ReportService {
    private final InventoryRepository inventoryRepository;
    private final SalesOrderRepository salesOrderRepository;
    private final ProductRepository productRepository;

    public ReportService(InventoryRepository inventoryRepository, 
                        SalesOrderRepository salesOrderRepository,
                        ProductRepository productRepository) {
        this.inventoryRepository = inventoryRepository;
        this.salesOrderRepository = salesOrderRepository;
        this.productRepository = productRepository;
    }

    public String generateInventoryReport() {
        List<InventoryItem> items = inventoryRepository.findAll();
        StringBuilder report = new StringBuilder();
        report.append("=== INVENTORY REPORT ===\n");
        report.append("Total Items: ").append(items.size()).append("\n\n");
        
        for (InventoryItem item : items) {
            report.append(String.format("Product: %s | Warehouse: %s | Quantity: %d\n", 
                    item.getProductId(), item.getWarehouseId(), item.getQuantity()));
        }
        
        return report.toString();
    }

    public String generateSalesReport(LocalDateTime startDate, LocalDateTime endDate) {
        List<SalesOrder> orders = salesOrderRepository.findAll().stream()
                .filter(order -> order.getOrderDate().isAfter(startDate) && 
                               order.getOrderDate().isBefore(endDate))
                .collect(Collectors.toList());
        
        StringBuilder report = new StringBuilder();
        report.append("=== SALES REPORT ===\n");
        report.append(String.format("Period: %s to %s\n", startDate.toLocalDate(), endDate.toLocalDate()));
        report.append("Total Orders: ").append(orders.size()).append("\n\n");
        
        for (SalesOrder order : orders) {
            report.append(String.format("Order: %s | Product: %s | Quantity: %d | Status: %s\n",
                    order.getOrderId(), order.getProductId(), order.getQuantity(), order.getStatus()));
        }
        
        return report.toString();
    }

    public String generateLowStockReport(int threshold) {
        List<InventoryItem> lowStockItems = inventoryRepository.findAll().stream()
                .filter(item -> item.getQuantity() <= threshold)
                .collect(Collectors.toList());
        
        StringBuilder report = new StringBuilder();
        report.append("=== LOW STOCK REPORT ===\n");
        report.append("Threshold: ").append(threshold).append("\n");
        report.append("Items Below Threshold: ").append(lowStockItems.size()).append("\n\n");
        
        for (InventoryItem item : lowStockItems) {
            report.append(String.format("Product: %s | Warehouse: %s | Current Stock: %d\n",
                    item.getProductId(), item.getWarehouseId(), item.getQuantity()));
        }
        
        return report.toString();
    }
}