package com.scms.service;

import com.scms.model.*;
import com.scms.repository.*;
import com.scms.exception.InsufficientStockException;
import com.scms.exception.InvalidQuantityException;
import com.scms.exception.EntityNotFoundException;
import java.time.LocalDateTime;

public class OrderService {
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final SalesOrderRepository salesOrderRepository;
    private final InventoryService inventoryService;

    public OrderService(PurchaseOrderRepository purchaseOrderRepository, 
                       SalesOrderRepository salesOrderRepository,
                       InventoryService inventoryService) {
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.salesOrderRepository = salesOrderRepository;
        this.inventoryService = inventoryService;
    }

    public PurchaseOrder createPurchaseOrder(String supplierId, String productId, int quantity) throws InvalidQuantityException {
        if (quantity <= 0) {
            throw new InvalidQuantityException(quantity);
        }
        String orderId = "PO_" + System.currentTimeMillis();
        PurchaseOrder order = new PurchaseOrder(orderId, supplierId, productId, quantity);
        return purchaseOrderRepository.save(order);
    }

    public SalesOrder createSalesOrder(String productId, int quantity, String customerDetails) throws InsufficientStockException, InvalidQuantityException {
        if (quantity <= 0) {
            throw new InvalidQuantityException(quantity);
        }
        // Check stock availability across all warehouses
        // For simplicity, assume we check the first warehouse with stock
        String orderId = "SO_" + System.currentTimeMillis();
        SalesOrder order = new SalesOrder(orderId, productId, quantity, customerDetails);
        return salesOrderRepository.save(order);
    }

    public void fulfillSalesOrder(String orderId) throws EntityNotFoundException {
        SalesOrder order = salesOrderRepository.findById(orderId)
                .orElseThrow(() -> new EntityNotFoundException("SalesOrder", orderId));
        order.setStatus(OrderStatus.FULFILLED);
        salesOrderRepository.save(order);
    }
    
    public void fulfillSalesOrderSafe(String orderId) {
        salesOrderRepository.findById(orderId).ifPresent(order -> {
            order.setStatus(OrderStatus.FULFILLED);
            salesOrderRepository.save(order);
            // Create shipment logic would go here
        });
    }
}