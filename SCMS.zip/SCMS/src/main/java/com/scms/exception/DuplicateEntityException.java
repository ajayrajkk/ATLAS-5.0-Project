package com.scms.exception;

public class DuplicateEntityException extends Exception {
    public DuplicateEntityException(String message) {
        super(message);
    }
    
    public DuplicateEntityException(String entityType, String id) {
        super(String.format("%s with ID '%s' already exists", entityType, id));
    }
}