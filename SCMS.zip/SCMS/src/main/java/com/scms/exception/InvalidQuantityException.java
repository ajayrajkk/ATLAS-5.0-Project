package com.scms.exception;

public class InvalidQuantityException extends Exception {
    public InvalidQuantityException(String message) {
        super(message);
    }
    
    public InvalidQuantityException(int quantity) {
        super(String.format("Invalid quantity: %d. Quantity must be positive", quantity));
    }
}