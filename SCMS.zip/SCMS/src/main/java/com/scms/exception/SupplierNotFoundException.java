package com.scms.exception;

/**
 * Custom exception thrown when a supplier is not found
 */
public class SupplierNotFoundException extends RuntimeException {
    
    public SupplierNotFoundException(String message) {
        super(message);
    }
    
    public SupplierNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}