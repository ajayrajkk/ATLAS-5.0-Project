package com.scms;

import com.scms.model.*;
import com.scms.service.*;
import com.scms.repository.*;
import com.scms.util.ConsoleHelper;
import com.scms.util.StringUtils;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Scanner;

public class SCMSApplication {
    private static ProductRepository productRepo;
    private static SupplierRepository supplierRepo;
    private static InventoryRepository inventoryRepo;
    private static PurchaseOrderRepository purchaseOrderRepo;
    private static SalesOrderRepository salesOrderRepo;
    
    private static InventoryService inventoryService;
    private static OrderService orderService;
    private static SupplierService supplierService;
    private static ReportService reportService;
    private static ProductService productService;
    
    private static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        initializeSystem();
        loadSampleData();
        runInteractiveCLI();
    }
    
    private static void initializeSystem() {
        System.out.println("Supply Chain Management System (SCMS)");
        System.out.println("=====================================");
        
        // Initialize repositories
        productRepo = new ProductRepository();
        supplierRepo = new SupplierRepository();
        inventoryRepo = new InventoryRepository();
        purchaseOrderRepo = new PurchaseOrderRepository();
        salesOrderRepo = new SalesOrderRepository();
        
        // Initialize services
        inventoryService = new InventoryService(inventoryRepo);
        orderService = new OrderService(purchaseOrderRepo, salesOrderRepo, inventoryService);
        supplierService = new SupplierService(supplierRepo);
        reportService = new ReportService(inventoryRepo, salesOrderRepo, productRepo);
        productService = new ProductService(productRepo);
        
        System.out.println("System initialized successfully!");
    }
    
    private static void loadSampleData() {
        try {
            System.out.println("\nLoading sample data...");
            
            // Create suppliers
            supplierService.createSupplier("SUP001", "TechCorp", "contact@techcorp.com", 4.5);
            supplierService.createSupplier("SUP002", "GlobalSupply", "info@globalsupply.com", 4.2);
            
            // Create products
            productRepo.save(new Product("PROD001", "Laptop", "Gaming Laptop", ProductCategory.ELECTRONICS, new BigDecimal("999.99")));
            productRepo.save(new Product("PROD002", "Mouse", "Wireless Mouse", ProductCategory.ELECTRONICS, new BigDecimal("29.99")));
            productRepo.save(new Product("PROD003", "Keyboard", "Mechanical Keyboard", ProductCategory.ELECTRONICS, new BigDecimal("79.99")));
            
            // Add initial stock
            inventoryService.addStock("PROD001", "WH001", 50);
            inventoryService.addStock("PROD002", "WH001", 100);
            inventoryService.addStock("PROD003", "WH001", 75);
            inventoryService.addStock("PROD001", "WH002", 30);
            
            System.out.println("Sample data loaded successfully!");
        } catch (Exception e) {
            System.err.println("Error loading sample data: " + e.getMessage());
        }
    }
    
    private static void runInteractiveCLI() {
        boolean running = true;
        
        while (running) {
            displayMainMenu();
            int choice = getIntInput("Enter your choice: ");
            
            try {
                switch (choice) {
                    case 1:
                        manageInventory();
                        break;
                    case 2:
                        manageOrders();
                        break;
                    case 3:
                        manageProducts();
                        break;
                    case 4:
                        generateReports();
                        break;
                    case 5:
                        demonstrateWorkflow();
                        break;
                    case 0:
                        running = false;
                        System.out.println("Thank you for using SCMS!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
            
            if (running) {
                System.out.println("\nPress Enter to continue...");
                scanner.nextLine();
            }
        }
    }
    
    private static void displayMainMenu() {
        System.out.println("\n" + StringUtils.repeat("=", 50));
        System.out.println("         SUPPLY CHAIN MANAGEMENT SYSTEM");
        System.out.println(StringUtils.repeat("=", 50));
        System.out.println("1. Inventory Management");
        System.out.println("2. Order Management");
        System.out.println("3. Product Management");
        System.out.println("4. Reports");
        System.out.println("5. Demonstrate Complete Workflow");
        System.out.println("0. Exit");
        System.out.println(StringUtils.repeat("=", 50));
    }
    
    private static void manageInventory() {
        System.out.println("\n--- INVENTORY MANAGEMENT ---");
        System.out.println("1. Add Stock");
        System.out.println("2. Remove Stock");
        System.out.println("3. Transfer Stock");
        System.out.println("4. Check Stock Level");
        System.out.println("5. View All Inventory");
        
        int choice = getIntInput("Enter your choice: ");
        
        try {
            switch (choice) {
                case 1:
                    addStock();
                    break;
                case 2:
                    removeStock();
                    break;
                case 3:
                    transferStock();
                    break;
                case 4:
                    checkStockLevel();
                    break;
                case 5:
                    System.out.println(reportService.generateInventoryReport());
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    private static void manageOrders() {
        System.out.println("\n--- ORDER MANAGEMENT ---");
        System.out.println("1. Create Purchase Order");
        System.out.println("2. Create Sales Order");
        System.out.println("3. Fulfill Sales Order");
        System.out.println("4. View All Orders");
        
        int choice = getIntInput("Enter your choice: ");
        
        try {
            switch (choice) {
                case 1:
                    createPurchaseOrder();
                    break;
                case 2:
                    createSalesOrder();
                    break;
                case 3:
                    fulfillSalesOrder();
                    break;
                case 4:
                    viewAllOrders();
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    private static void manageProducts() {
        System.out.println("\n--- PRODUCT MANAGEMENT ---");
        System.out.println("1. Add New Product");
        System.out.println("2. View All Products");
        System.out.println("3. Find Product by ID");
        
        int choice = getIntInput("Enter your choice: ");
        
        try {
            switch (choice) {
                case 1:
                    addNewProduct();
                    break;
                case 2:
                    viewAllProducts();
                    break;
                case 3:
                    findProductById();
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    private static void generateReports() {
        System.out.println("\n--- REPORTS ---");
        System.out.println("1. Inventory Report");
        System.out.println("2. Low Stock Report");
        System.out.println("3. Sales Report");
        
        int choice = getIntInput("Enter your choice: ");
        
        try {
            switch (choice) {
                case 1:
                    System.out.println(reportService.generateInventoryReport());
                    break;
                case 2:
                    int threshold = getIntInput("Enter low stock threshold: ");
                    System.out.println(reportService.generateLowStockReport(threshold));
                    break;
                case 3:
                    LocalDateTime startDate = LocalDateTime.now().minusDays(30);
                    LocalDateTime endDate = LocalDateTime.now();
                    System.out.println(reportService.generateSalesReport(startDate, endDate));
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    private static void demonstrateWorkflow() {
        System.out.println("\n--- COMPLETE WORKFLOW DEMONSTRATION ---");
        System.out.println("This will demonstrate: Add Stock → Create Sales Order → Fulfill Order");
        
        try {
            // Step 1: Show current inventory
            System.out.println("\n1. Current Inventory Status:");
            System.out.println("PROD001 (Laptop) in WH001: " + inventoryService.getStockLevel("PROD001", "WH001"));
            
            // Step 2: Add more stock
            System.out.println("\n2. Adding 20 more laptops to WH001...");
            inventoryService.addStock("PROD001", "WH001", 20);
            System.out.println("New stock level: " + inventoryService.getStockLevel("PROD001", "WH001"));
            
            // Step 3: Create sales order
            System.out.println("\n3. Creating sales order for 5 laptops...");
            SalesOrder order = orderService.createSalesOrder("PROD001", 5, "Demo Customer - ABC Corp, 456 Business Ave");
            System.out.println("Sales Order Created: " + order.getOrderId());
            System.out.println("Order Status: " + order.getStatus());
            
            // Step 4: Simulate inventory reduction for fulfillment
            System.out.println("\n4. Processing order fulfillment...");
            inventoryService.removeStock("PROD001", "WH001", 5);
            System.out.println("Inventory reduced by 5 units");
            
            // Step 5: Fulfill the order
            orderService.fulfillSalesOrder(order.getOrderId());
            System.out.println("Order fulfilled successfully!");
            
            // Step 6: Show final status
            System.out.println("\n5. Final Status:");
            System.out.println("Remaining stock: " + inventoryService.getStockLevel("PROD001", "WH001"));
            System.out.println("Order status: " + salesOrderRepo.findById(order.getOrderId()).get().getStatus());
            
            System.out.println("\n✓ Workflow completed successfully!");
            
        } catch (Exception e) {
            System.err.println("Workflow error: " + e.getMessage());
        }
    }
    
    // Helper methods for individual operations
    private static void addStock() throws Exception {
        String productId = getStringInput("Enter Product ID: ");
        String warehouseId = getStringInput("Enter Warehouse ID: ");
        int quantity = getIntInput("Enter quantity to add: ");
        
        inventoryService.addStock(productId, warehouseId, quantity);
        System.out.println("Stock added successfully!");
        System.out.println("New stock level: " + inventoryService.getStockLevel(productId, warehouseId));
    }
    
    private static void removeStock() throws Exception {
        String productId = getStringInput("Enter Product ID: ");
        String warehouseId = getStringInput("Enter Warehouse ID: ");
        int quantity = getIntInput("Enter quantity to remove: ");
        
        inventoryService.removeStock(productId, warehouseId, quantity);
        System.out.println("Stock removed successfully!");
        System.out.println("New stock level: " + inventoryService.getStockLevel(productId, warehouseId));
    }
    
    private static void transferStock() throws Exception {
        String productId = getStringInput("Enter Product ID: ");
        String fromWarehouse = getStringInput("Enter source warehouse ID: ");
        String toWarehouse = getStringInput("Enter destination warehouse ID: ");
        int quantity = getIntInput("Enter quantity to transfer: ");
        
        inventoryService.transferStock(productId, fromWarehouse, toWarehouse, quantity);
        System.out.println("Stock transferred successfully!");
        System.out.println("Source warehouse stock: " + inventoryService.getStockLevel(productId, fromWarehouse));
        System.out.println("Destination warehouse stock: " + inventoryService.getStockLevel(productId, toWarehouse));
    }
    
    private static void checkStockLevel() {
        String productId = getStringInput("Enter Product ID: ");
        String warehouseId = getStringInput("Enter Warehouse ID: ");
        
        int stock = inventoryService.getStockLevel(productId, warehouseId);
        System.out.println("Stock level for " + productId + " in " + warehouseId + ": " + stock);
    }
    
    private static void createPurchaseOrder() throws Exception {
        String supplierId = getStringInput("Enter Supplier ID: ");
        String productId = getStringInput("Enter Product ID: ");
        int quantity = getIntInput("Enter quantity: ");
        
        PurchaseOrder order = orderService.createPurchaseOrder(supplierId, productId, quantity);
        System.out.println("Purchase Order created: " + order.getOrderId());
        System.out.println("Status: " + order.getStatus());
    }
    
    private static void createSalesOrder() throws Exception {
        String productId = getStringInput("Enter Product ID: ");
        int quantity = getIntInput("Enter quantity: ");
        String customerDetails = getStringInput("Enter customer details: ");
        
        SalesOrder order = orderService.createSalesOrder(productId, quantity, customerDetails);
        System.out.println("Sales Order created: " + order.getOrderId());
        System.out.println("Status: " + order.getStatus());
    }
    
    private static void fulfillSalesOrder() throws Exception {
        String orderId = getStringInput("Enter Sales Order ID: ");
        
        orderService.fulfillSalesOrder(orderId);
        System.out.println("Sales Order fulfilled successfully!");
    }
    
    private static void viewAllOrders() {
        System.out.println("\n--- PURCHASE ORDERS ---");
        purchaseOrderRepo.findAll().forEach(order -> 
            System.out.println(order.getOrderId() + " | " + order.getProductId() + " | Qty: " + order.getQuantity() + " | Status: " + order.getStatus()));
        
        System.out.println("\n--- SALES ORDERS ---");
        salesOrderRepo.findAll().forEach(order -> 
            System.out.println(order.getOrderId() + " | " + order.getProductId() + " | Qty: " + order.getQuantity() + " | Status: " + order.getStatus()));
    }
    
    private static void addNewProduct() {
        String productId = getStringInput("Enter Product ID: ");
        String name = getStringInput("Enter Product Name: ");
        String description = getStringInput("Enter Description: ");
        
        System.out.println("Available categories: ELECTRONICS, CLOTHING, FOOD, BOOKS, HOME, SPORTS, AUTOMOTIVE, HEALTH, OTHER");
        String categoryStr = getStringInput("Enter Category: ").toUpperCase();
        ProductCategory category = ProductCategory.valueOf(categoryStr);
        
        BigDecimal price = new BigDecimal(getStringInput("Enter Unit Price: "));
        
        Product product = new Product(productId, name, description, category, price);
        productRepo.save(product);
        System.out.println("Product added successfully!");
    }
    
    private static void viewAllProducts() {
        System.out.println("\n--- ALL PRODUCTS ---");
        productRepo.findAll().forEach(product -> 
            System.out.println(product.getProductId() + " | " + product.getName() + " | $" + product.getUnitPrice() + " | " + product.getCategory()));
    }
    
    private static void findProductById() {
        String productId = getStringInput("Enter Product ID: ");
        if (productRepo.findById(productId).isPresent()) {
            System.out.println("Found: " + productRepo.findById(productId).get());
        } else {
            System.out.println("Product not found.");
        }
    }
    
    // Utility methods
    private static String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    
    private static int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = Integer.parseInt(scanner.nextLine().trim());
                return value;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}