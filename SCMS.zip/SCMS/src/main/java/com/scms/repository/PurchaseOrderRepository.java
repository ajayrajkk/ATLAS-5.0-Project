package com.scms.repository;

import com.scms.model.PurchaseOrder;
import java.util.*;

public class PurchaseOrderRepository {
    private final Map<String, PurchaseOrder> purchaseOrders;

    public PurchaseOrderRepository() {
        this.purchaseOrders = new HashMap<>();
    }

    public PurchaseOrder save(PurchaseOrder order) {
        purchaseOrders.put(order.getOrderId(), order);
        return order;
    }

    public Optional<PurchaseOrder> findById(String orderId) {
        return Optional.ofNullable(purchaseOrders.get(orderId));
    }

    public List<PurchaseOrder> findAll() {
        return new ArrayList<>(purchaseOrders.values());
    }

    public boolean deleteById(String orderId) {
        return purchaseOrders.remove(orderId) != null;
    }

    public boolean existsById(String orderId) {
        return purchaseOrders.containsKey(orderId);
    }
}