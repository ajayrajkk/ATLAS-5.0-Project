package com.scms.repository;

import com.scms.model.InventoryItem;
import java.util.*;

public class InventoryRepository {
    private final Map<String, InventoryItem> inventory;

    public InventoryRepository() {
        this.inventory = new HashMap<>();
    }

    public InventoryItem save(InventoryItem item) {
        String key = item.getProductId() + "_" + item.getWarehouseId();
        inventory.put(key, item);
        return item;
    }

    public Optional<InventoryItem> findByProductAndWarehouse(String productId, String warehouseId) {
        String key = productId + "_" + warehouseId;
        return Optional.ofNullable(inventory.get(key));
    }

    public List<InventoryItem> findAll() {
        return new ArrayList<>(inventory.values());
    }

    public List<InventoryItem> findByProductId(String productId) {
        return inventory.values().stream()
                .filter(item -> productId.equals(item.getProductId()))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public boolean deleteByProductAndWarehouse(String productId, String warehouseId) {
        String key = productId + "_" + warehouseId;
        return inventory.remove(key) != null;
    }
}