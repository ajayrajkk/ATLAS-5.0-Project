package com.scms.repository;

import com.scms.model.SalesOrder;
import java.util.*;

public class SalesOrderRepository {
    private final Map<String, SalesOrder> salesOrders;

    public SalesOrderRepository() {
        this.salesOrders = new HashMap<>();
    }

    public SalesOrder save(SalesOrder order) {
        salesOrders.put(order.getOrderId(), order);
        return order;
    }

    public Optional<SalesOrder> findById(String orderId) {
        return Optional.ofNullable(salesOrders.get(orderId));
    }

    public List<SalesOrder> findAll() {
        return new ArrayList<>(salesOrders.values());
    }

    public boolean deleteById(String orderId) {
        return salesOrders.remove(orderId) != null;
    }

    public boolean existsById(String orderId) {
        return salesOrders.containsKey(orderId);
    }
}