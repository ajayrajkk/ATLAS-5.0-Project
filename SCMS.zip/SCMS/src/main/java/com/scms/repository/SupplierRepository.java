package com.scms.repository;

import com.scms.model.Supplier;
import java.util.*;

/**
 * Repository class for Supplier data access operations
 */
public class SupplierRepository {
    private final Map<String, Supplier> suppliers;

    public SupplierRepository() {
        this.suppliers = new HashMap<>();
    }

    public Supplier save(Supplier supplier) {
        if (supplier.getSupplierId() == null || supplier.getSupplierId().trim().isEmpty()) {
            throw new IllegalArgumentException("Supplier ID cannot be null or empty");
        }
        suppliers.put(supplier.getSupplierId(), supplier);
        return supplier;
    }

    public Optional<Supplier> findById(String supplierId) {
        return Optional.ofNullable(suppliers.get(supplierId));
    }

    public List<Supplier> findAll() {
        return new ArrayList<>(suppliers.values());
    }

    public List<Supplier> findByRatingAbove(double rating) {
        return suppliers.values().stream()
                .filter(supplier -> supplier.getRating() >= rating)
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public boolean deleteById(String supplierId) {
        return suppliers.remove(supplierId) != null;
    }

    public boolean existsById(String supplierId) {
        return suppliers.containsKey(supplierId);
    }

    public int count() {
        return suppliers.size();
    }

    public void clear() {
        suppliers.clear();
    }
}