package com.scms.repository;

import com.scms.model.Product;
import com.scms.model.ProductCategory;
import java.util.*;

/**
 * Repository class for Product data access operations
 */
public class ProductRepository {
    private final Map<String, Product> products;

    public ProductRepository() {
        this.products = new HashMap<>();
    }

    public Product save(Product product) {
        if (product.getProductId() == null || product.getProductId().trim().isEmpty()) {
            throw new IllegalArgumentException("Product ID cannot be null or empty");
        }
        products.put(product.getProductId(), product);
        return product;
    }

    public Optional<Product> findById(String productId) {
        return Optional.ofNullable(products.get(productId));
    }

    public List<Product> findAll() {
        return new ArrayList<>(products.values());
    }

    public List<Product> findByCategory(ProductCategory category) {
        return products.values().stream()
                .filter(product -> category.equals(product.getCategory()))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public boolean deleteById(String productId) {
        return products.remove(productId) != null;
    }

    public boolean existsById(String productId) {
        return products.containsKey(productId);
    }

    public int count() {
        return products.size();
    }

    public void clear() {
        products.clear();
    }
}