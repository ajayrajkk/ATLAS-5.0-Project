package com.scms.model;

public enum ProductCategory {
    ELECTRONICS,
    CLOTHING,
    FOOD,
    BOOKS,
    HOME,
    SPORTS,
    AUTOMOTIVE,
    HEALTH,
    OTHER
}