package com.scms.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Shipment {
    private String shipmentId;
    private String orderId;
    private String originWarehouseId;
    private String destination;
    private LocalDateTime shipmentDate;
    private ShipmentStatus status;

    public Shipment() {
        this.shipmentDate = LocalDateTime.now();
        this.status = ShipmentStatus.IN_TRANSIT;
    }

    public Shipment(String shipmentId, String orderId, String originWarehouseId, String destination) {
        this();
        this.shipmentId = shipmentId;
        this.orderId = orderId;
        this.originWarehouseId = originWarehouseId;
        this.destination = destination;
    }

    public String getShipmentId() { return shipmentId; }
    public void setShipmentId(String shipmentId) { this.shipmentId = shipmentId; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getOriginWarehouseId() { return originWarehouseId; }
    public void setOriginWarehouseId(String originWarehouseId) { this.originWarehouseId = originWarehouseId; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public LocalDateTime getShipmentDate() { return shipmentDate; }
    public void setShipmentDate(LocalDateTime shipmentDate) { this.shipmentDate = shipmentDate; }

    public ShipmentStatus getStatus() { return status; }
    public void setStatus(ShipmentStatus status) { this.status = status; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Shipment shipment = (Shipment) o;
        return Objects.equals(shipmentId, shipment.shipmentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(shipmentId);
    }

    @Override
    public String toString() {
        return String.format("Shipment{id='%s', order='%s', from='%s', to='%s', status='%s'}", 
                           shipmentId, orderId, originWarehouseId, destination, status);
    }
}