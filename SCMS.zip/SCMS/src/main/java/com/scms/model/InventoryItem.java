package com.scms.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class InventoryItem {
    private String itemId;
    private String productId;
    private String warehouseId;
    private int quantity;
    private LocalDateTime lastRestockedDate;

    public InventoryItem() {
        this.lastRestockedDate = LocalDateTime.now();
    }

    public InventoryItem(String itemId, String productId, String warehouseId, int quantity, LocalDateTime lastRestockedDate) {
        this.itemId = itemId;
        this.productId = productId;
        this.warehouseId = warehouseId;
        this.quantity = quantity;
        this.lastRestockedDate = lastRestockedDate;
    }

    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getWarehouseId() { return warehouseId; }
    public void setWarehouseId(String warehouseId) { this.warehouseId = warehouseId; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public LocalDateTime getLastRestockedDate() { return lastRestockedDate; }
    public void setLastRestockedDate(LocalDateTime lastRestockedDate) { this.lastRestockedDate = lastRestockedDate; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InventoryItem that = (InventoryItem) o;
        return Objects.equals(itemId, that.itemId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(itemId);
    }

    @Override
    public String toString() {
        return String.format("InventoryItem{id='%s', productId='%s', warehouseId='%s', quantity=%d}", 
                           itemId, productId, warehouseId, quantity);
    }
}