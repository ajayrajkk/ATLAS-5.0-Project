package com.scms.model;

public enum OrderStatus {
    PENDING,
    DELIVERED,
    CANCELLED,
    PROCESSING,
    FULFILLED
}