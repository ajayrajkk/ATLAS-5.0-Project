package com.scms.model;

public enum ShipmentStatus {
    IN_TRANSIT,
    DELIVERED
}