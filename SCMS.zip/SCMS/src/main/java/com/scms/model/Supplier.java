package com.scms.model;

import java.util.Objects;

public class Supplier {
    private String supplierId;
    private String name;
    private String contactInfo;
    private double rating;

    public Supplier() {}

    public Supplier(String supplierId, String name, String contactInfo, double rating) {
        this.supplierId = supplierId;
        this.name = name;
        this.contactInfo = contactInfo;
        this.rating = rating;
    }

    public String getSupplierId() { return supplierId; }
    public void setSupplierId(String supplierId) { this.supplierId = supplierId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getContactInfo() { return contactInfo; }
    public void setContactInfo(String contactInfo) { this.contactInfo = contactInfo; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Supplier supplier = (Supplier) o;
        return Objects.equals(supplierId, supplier.supplierId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(supplierId);
    }

    @Override
    public String toString() {
        return String.format("Supplier{id='%s', name='%s', contact='%s', rating=%.1f}", 
                           supplierId, name, contactInfo, rating);
    }
}