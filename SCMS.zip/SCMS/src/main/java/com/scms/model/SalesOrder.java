package com.scms.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class SalesOrder {
    private String orderId;
    private String productId;
    private int quantity;
    private LocalDateTime orderDate;
    private OrderStatus status;
    private String customerDetails;

    public SalesOrder() {
        this.orderDate = LocalDateTime.now();
        this.status = OrderStatus.PROCESSING;
    }

    public SalesOrder(String orderId, String productId, int quantity, String customerDetails) {
        this();
        this.orderId = orderId;
        this.productId = productId;
        this.quantity = quantity;
        this.customerDetails = customerDetails;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public LocalDateTime getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDateTime orderDate) { this.orderDate = orderDate; }

    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }

    public String getCustomerDetails() { return customerDetails; }
    public void setCustomerDetails(String customerDetails) { this.customerDetails = customerDetails; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SalesOrder that = (SalesOrder) o;
        return Objects.equals(orderId, that.orderId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId);
    }

    @Override
    public String toString() {
        return String.format("SalesOrder{id='%s', product='%s', qty=%d, customer='%s', status='%s'}", 
                           orderId, productId, quantity, customerDetails, status);
    }
}