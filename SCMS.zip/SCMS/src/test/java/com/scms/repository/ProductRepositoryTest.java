package com.scms.repository;

import com.scms.model.Product;
import com.scms.model.ProductCategory;
import org.testng.Assert;
import org.testng.annotations.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public class ProductRepositoryTest {
    private ProductRepository productRepository;
    private Product testProduct;

    @BeforeMethod
    public void setUp() {
        productRepository = new ProductRepository();
        testProduct = new Product("PROD001", "Laptop", "Gaming Laptop", ProductCategory.ELECTRONICS, new BigDecimal("999.99"));
    }

    @Test(groups = "repository")
    public void testSaveProduct() {
        Product saved = productRepository.save(testProduct);
        
        Assert.assertNotNull(saved);
        Assert.assertEquals(saved.getProductId(), "PROD001");
        Assert.assertEquals(saved.getName(), "Laptop");
    }

    @Test(groups = "repository", expectedExceptions = IllegalArgumentException.class)
    public void testSaveProductWithNullId() {
        Product invalidProduct = new Product(null, "Test", "Test Product", ProductCategory.ELECTRONICS, new BigDecimal("10.00"));
        productRepository.save(invalidProduct);
    }

    @Test(groups = "repository", expectedExceptions = IllegalArgumentException.class)
    public void testSaveProductWithEmptyId() {
        Product invalidProduct = new Product("", "Test", "Test Product", ProductCategory.ELECTRONICS, new BigDecimal("10.00"));
        productRepository.save(invalidProduct);
    }

    @Test(groups = "repository")
    public void testFindById() {
        productRepository.save(testProduct);
        
        Optional<Product> found = productRepository.findById("PROD001");
        
        Assert.assertTrue(found.isPresent());
        Assert.assertEquals(found.get().getName(), "Laptop");
    }

    @Test(groups = "repository")
    public void testFindByIdNotFound() {
        Optional<Product> found = productRepository.findById("NONEXISTENT");
        Assert.assertFalse(found.isPresent());
    }

    @Test(groups = "repository")
    public void testFindAll() {
        Product product2 = new Product("PROD002", "Mouse", "Wireless Mouse", ProductCategory.ELECTRONICS, new BigDecimal("29.99"));
        
        productRepository.save(testProduct);
        productRepository.save(product2);
        
        List<Product> products = productRepository.findAll();
        
        Assert.assertEquals(products.size(), 2);
    }

    @DataProvider(name = "productData")
    public Object[][] provideProductData() {
        return new Object[][] {
            { "PROD001", "Laptop", ProductCategory.ELECTRONICS, new BigDecimal("999.99") },
            { "PROD002", "Chair", ProductCategory.HOME, new BigDecimal("199.99") },
            { "PROD003", "Book", ProductCategory.BOOKS, new BigDecimal("19.99") }
        };
    }

    @Test(groups = "repository", dataProvider = "productData")
    public void testSaveMultipleProducts(String id, String name, ProductCategory category, BigDecimal price) {
        Product product = new Product(id, name, "Test Description", category, price);
        Product saved = productRepository.save(product);
        
        Assert.assertEquals(saved.getProductId(), id);
        Assert.assertEquals(saved.getName(), name);
        Assert.assertEquals(saved.getCategory(), category);
    }

    @Test(groups = "repository")
    public void testFindByCategory() {
        Product electronics1 = new Product("PROD001", "Laptop", "Gaming Laptop", ProductCategory.ELECTRONICS, new BigDecimal("999.99"));
        Product electronics2 = new Product("PROD002", "Mouse", "Wireless Mouse", ProductCategory.ELECTRONICS, new BigDecimal("29.99"));
        Product furniture = new Product("PROD003", "Chair", "Office Chair", ProductCategory.HOME, new BigDecimal("199.99"));
        
        productRepository.save(electronics1);
        productRepository.save(electronics2);
        productRepository.save(furniture);
        
        List<Product> electronicsProducts = productRepository.findByCategory(ProductCategory.ELECTRONICS);
        
        Assert.assertEquals(electronicsProducts.size(), 2);
    }

    @Test(groups = "repository")
    public void testDeleteById() {
        productRepository.save(testProduct);
        
        boolean deleted = productRepository.deleteById("PROD001");
        
        Assert.assertTrue(deleted);
        Assert.assertFalse(productRepository.existsById("PROD001"));
    }

    @Test(groups = "repository")
    public void testDeleteByIdNotFound() {
        boolean deleted = productRepository.deleteById("NONEXISTENT");
        Assert.assertFalse(deleted);
    }

    @Test(groups = "repository")
    public void testExistsById() {
        productRepository.save(testProduct);
        
        Assert.assertTrue(productRepository.existsById("PROD001"));
        Assert.assertFalse(productRepository.existsById("NONEXISTENT"));
    }

    @Test(groups = "repository")
    public void testCount() {
        Assert.assertEquals(productRepository.count(), 0);
        
        productRepository.save(testProduct);
        Assert.assertEquals(productRepository.count(), 1);
        
        Product product2 = new Product("PROD002", "Mouse", "Wireless Mouse", ProductCategory.ELECTRONICS, new BigDecimal("29.99"));
        productRepository.save(product2);
        Assert.assertEquals(productRepository.count(), 2);
    }

    @Test(groups = "repository")
    public void testClear() {
        productRepository.save(testProduct);
        Assert.assertEquals(productRepository.count(), 1);
        
        productRepository.clear();
        Assert.assertEquals(productRepository.count(), 0);
    }
}