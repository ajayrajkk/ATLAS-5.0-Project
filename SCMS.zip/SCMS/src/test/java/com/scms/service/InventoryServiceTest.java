package com.scms.service;

import com.scms.model.InventoryItem;
import com.scms.repository.InventoryRepository;
import com.scms.exception.InsufficientStockException;
import com.scms.exception.InvalidQuantityException;
import org.testng.Assert;
import org.testng.annotations.*;

public class InventoryServiceTest {
    private InventoryService inventoryService;
    private InventoryRepository inventoryRepository;
    private final String TEST_PRODUCT_ID = "PROD001";
    private final String TEST_WAREHOUSE_ID = "WH001";
    private final String TEST_WAREHOUSE_ID_2 = "WH002";

    @BeforeMethod
    public void setUp() throws InvalidQuantityException {
        inventoryRepository = new InventoryRepository();
        inventoryService = new InventoryService(inventoryRepository);
        inventoryService.addStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 10);
    }
    
    @AfterMethod
    public void tearDown() {
        // Cleanup handled by creating new instances in @BeforeMethod
    }

    @Test(groups = "inventory")
    public void testAddStockToNewProduct() throws InvalidQuantityException {
        inventoryService.addStock("PROD002", TEST_WAREHOUSE_ID, 5);
        int stock = inventoryService.getStockLevel("PROD002", TEST_WAREHOUSE_ID);
        Assert.assertEquals(stock, 5);
    }

    @Test(groups = "inventory")
    public void testAddStockToExistingProduct() throws InvalidQuantityException {
        inventoryService.addStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 5);
        int stock = inventoryService.getStockLevel(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID);
        Assert.assertEquals(stock, 15);
    }

    @Test(groups = "inventory")
    public void testRemoveStockSuccess() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.removeStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 5);
        int stock = inventoryService.getStockLevel(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID);
        Assert.assertEquals(stock, 5);
    }

    @Test(groups = "inventory", expectedExceptions = InsufficientStockException.class)
    public void testRemoveStockExceedingQuantity() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.removeStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 15);
    }

    @Test(groups = "inventory", expectedExceptions = InsufficientStockException.class)
    public void testRemoveStockFromNonExistentProduct() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.removeStock("NONEXISTENT", TEST_WAREHOUSE_ID, 1);
    }

    @DataProvider(name = "stockTransferData")
    public Object[][] provideStockTransferData() {
        return new Object[][] {
            { 2, 8, 2 },
            { 5, 5, 5 },
            { 1, 9, 1 }
        };
    }

    @Test(groups = "inventory", dataProvider = "stockTransferData")
    public void testStockTransferSuccess(int transferQty, int expectedSource, int expectedDest) throws InsufficientStockException, InvalidQuantityException {
        inventoryService.transferStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, TEST_WAREHOUSE_ID_2, transferQty);
        
        int sourceStock = inventoryService.getStockLevel(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID);
        int destStock = inventoryService.getStockLevel(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID_2);
        
        Assert.assertEquals(sourceStock, expectedSource);
        Assert.assertEquals(destStock, expectedDest);
    }

    @Test(groups = "inventory", expectedExceptions = InsufficientStockException.class)
    public void testTransferStockInsufficientQuantity() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.transferStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, TEST_WAREHOUSE_ID_2, 15);
    }

    @Test(groups = "inventory")
    public void testGetStockLevelNonExistentProduct() {
        int stock = inventoryService.getStockLevel("NONEXISTENT", TEST_WAREHOUSE_ID);
        Assert.assertEquals(stock, 0);
    }

    @DataProvider(name = "invalidQuantityData")
    public Object[][] provideInvalidQuantityData() {
        return new Object[][] {
            { -5 },   // Negative quantity
            { -1 },   // Negative quantity
            { 0 }     // Zero quantity for removal
        };
    }

    @Test(groups = "inventory", expectedExceptions = InvalidQuantityException.class)
    public void testAddStockWithNegativeQuantity() throws InvalidQuantityException {
        inventoryService.addStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, -5);
    }
    
    @Test(groups = "inventory", expectedExceptions = InvalidQuantityException.class)
    public void testRemoveStockWithZeroQuantity() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.removeStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 0);
    }
    
    @Test(groups = "inventory", expectedExceptions = InvalidQuantityException.class)
    public void testRemoveStockWithNegativeQuantity() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.removeStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, -1);
    }
    
    @Test(groups = "inventory", expectedExceptions = InvalidQuantityException.class)
    public void testTransferStockWithNegativeQuantity() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.transferStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, TEST_WAREHOUSE_ID_2, -1);
    }

    @Test(groups = "inventory", expectedExceptions = InvalidQuantityException.class)
    public void testTransferZeroQuantity() throws InsufficientStockException, InvalidQuantityException {
        inventoryService.transferStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, TEST_WAREHOUSE_ID_2, 0);
    }

    @Test(groups = "inventory")
    public void testStockNeverGoesNegative() throws InsufficientStockException, InvalidQuantityException {
        // Remove all stock
        inventoryService.removeStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 10);
        int stock = inventoryService.getStockLevel(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID);
        Assert.assertEquals(stock, 0);
        
        // Verify we cannot go below zero
        try {
            inventoryService.removeStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 1);
            Assert.fail("Should throw InsufficientStockException");
        } catch (InsufficientStockException e) {
            // Expected behavior
            Assert.assertTrue(true);
        }
    }

    @Test(groups = "inventory", priority = 1)
    public void testBoundaryConditions() throws InsufficientStockException, InvalidQuantityException {
        // Test removing exact available quantity
        inventoryService.removeStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 10);
        int stock = inventoryService.getStockLevel(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID);
        Assert.assertEquals(stock, 0);
        
        // Test adding to zero stock
        inventoryService.addStock(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID, 5);
        stock = inventoryService.getStockLevel(TEST_PRODUCT_ID, TEST_WAREHOUSE_ID);
        Assert.assertEquals(stock, 5);
    }
}