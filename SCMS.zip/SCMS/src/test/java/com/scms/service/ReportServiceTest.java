package com.scms.service;

import com.scms.model.*;
import com.scms.repository.*;
import org.testng.Assert;
import org.testng.annotations.*;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import com.scms.exception.InvalidQuantityException;

public class ReportServiceTest {
    private ReportService reportService;
    private InventoryRepository inventoryRepository;
    private SalesOrderRepository salesOrderRepository;
    private ProductRepository productRepository;
    private InventoryService inventoryService;

    @BeforeMethod
    public void setUp() throws InvalidQuantityException {
        inventoryRepository = new InventoryRepository();
        salesOrderRepository = new SalesOrderRepository();
        productRepository = new ProductRepository();
        inventoryService = new InventoryService(inventoryRepository);
        reportService = new ReportService(inventoryRepository, salesOrderRepository, productRepository);
        
        setupTestData();
    }

    private void setupTestData() throws InvalidQuantityException {
        Product product1 = new Product("PROD001", "Laptop", "Gaming Laptop", ProductCategory.ELECTRONICS, new BigDecimal("999.99"));
        Product product2 = new Product("PROD002", "Mouse", "Wireless Mouse", ProductCategory.ELECTRONICS, new BigDecimal("29.99"));
        productRepository.save(product1);
        productRepository.save(product2);
        
        inventoryService.addStock("PROD001", "WH001", 15);
        inventoryService.addStock("PROD002", "WH001", 3);
        inventoryService.addStock("PROD001", "WH002", 8);
        
        SalesOrder order1 = new SalesOrder("SO001", "PROD001", 2, "Customer A");
        SalesOrder order2 = new SalesOrder("SO002", "PROD002", 1, "Customer B");
        order2.setOrderDate(LocalDateTime.now().minusDays(1));
        salesOrderRepository.save(order1);
        salesOrderRepository.save(order2);
    }

    @Test(groups = "reports")
    public void testGenerateInventoryReport() {
        String report = reportService.generateInventoryReport();
        
        Assert.assertNotNull(report);
        Assert.assertTrue(report.contains("INVENTORY REPORT"));
        Assert.assertTrue(report.contains("PROD001"));
        Assert.assertTrue(report.contains("PROD002"));
    }

    @Test(groups = "reports")
    public void testGenerateSalesReport() {
        LocalDateTime startDate = LocalDateTime.now().minusDays(2);
        LocalDateTime endDate = LocalDateTime.now().plusDays(1);
        
        String report = reportService.generateSalesReport(startDate, endDate);
        
        Assert.assertNotNull(report);
        Assert.assertTrue(report.contains("SALES REPORT"));
        Assert.assertTrue(report.contains("SO001"));
    }

    @DataProvider(name = "lowStockThresholds")
    public Object[][] provideLowStockThresholds() {
        return new Object[][] {
            { 5, 1 },
            { 10, 2 },
            { 20, 3 }
        };
    }

    @Test(groups = "reports", dataProvider = "lowStockThresholds")
    public void testGenerateLowStockReport(int threshold, int expectedItemsCount) {
        String report = reportService.generateLowStockReport(threshold);
        
        Assert.assertNotNull(report);
        Assert.assertTrue(report.contains("LOW STOCK REPORT"));
        Assert.assertTrue(report.contains("Threshold: " + threshold));
    }
}