# Supply Chain Management System (SCMS)

A CLI-based Supply Chain Management System built with Java and Maven.

## Prerequisites

- Java 8 or higher
- Maven 3.6 or higher

## Project Structure

```
SCMS/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/scms/
│   │   │       ├── exception/
│   │   │       │   ├── DuplicateEntityException.java
│   │   │       │   ├── EntityNotFoundException.java
│   │   │       │   ├── InsufficientStockException.java
│   │   │       │   ├── InvalidProductDataException.java
│   │   │       │   ├── InvalidQuantityException.java
│   │   │       │   ├── ProductNotFoundException.java
│   │   │       │   └── SupplierNotFoundException.java
│   │   │       ├── model/
│   │   │       │   ├── InventoryItem.java
│   │   │       │   ├── OrderStatus.java
│   │   │       │   ├── Product.java
│   │   │       │   ├── ProductCategory.java
│   │   │       │   ├── PurchaseOrder.java
│   │   │       │   ├── SalesOrder.java
│   │   │       │   ├── Shipment.java
│   │   │       │   ├── ShipmentStatus.java
│   │   │       │   ├── Supplier.java
│   │   │       │   └── Warehouse.java
│   │   │       ├── repository/
│   │   │       │   ├── InventoryRepository.java
│   │   │       │   ├── ProductRepository.java
│   │   │       │   ├── PurchaseOrderRepository.java
│   │   │       │   ├── SalesOrderRepository.java
│   │   │       │   └── SupplierRepository.java
│   │   │       ├── service/
│   │   │       │   ├── InventoryService.java
│   │   │       │   ├── OrderService.java
│   │   │       │   ├── ProductService.java
│   │   │       │   ├── ReportService.java
│   │   │       │   └── SupplierService.java
│   │   │       ├── util/
│   │   │       │   ├── ConsoleHelper.java
│   │   │       │   ├── InputValidator.java
│   │   │       │   └── StringUtils.java
│   │   │       └── SCMSApplication.java
│   │   └── resources/
│   └── test/
│       └── java/
│           └── com/scms/
│               ├── repository/
│               │   └── ProductRepositoryTest.java
│               └── service/
│                   ├── InventoryServiceTest.java
│                   ├── OrderServiceTest.java
│                   └── ReportServiceTest.java
├── target/                    # Compiled classes and test reports
├── pom.xml
├── README.md
├── scms.txt                   # Project documentation
└── Project_ Supply Chain Management System (SCMS) - CLI Backend.pdf
```

## Build

```bash
mvn clean compile
```

## Run

### Option 1: Using Maven (Recommended)
```bash
mvn clean compile exec:java
```

### Option 2: Using Maven with main class (PowerShell)
```powershell
mvn exec:java -Dexec.mainClass='com.scms.SCMSApplication'
```

### Option 3: Using Java directly
```bash
mvn clean compile
java -cp target/classes com.scms.SCMSApplication
```

### Option 4: Build JAR and run
```bash
mvn clean package
java -jar target/supply-chain-management-system-1.0.0.jar
```

## Test

```bash
mvn test
```

## Features

- **Product Management**: Add, view, update, delete products
- **Supplier Management**: Manage supplier information
- **Stock Management**: Update inventory levels
- **Reports**: View system statistics and low stock alerts

## Usage

1. Run the application using one of the methods above
2. Navigate through the CLI menu system
3. Use the numbered options to perform operations
4. Follow the prompts for data entry

## Sample Data

The application initializes with sample products and suppliers for demonstration purposes.